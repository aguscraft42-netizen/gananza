# Prompt para Codex — integrar landing Gananza sin reinterpretar

Integrá el componente `GananzaLanding.tsx` en la página pública principal del proyecto Gananza.

## Regla principal

No rediseñes, no reescribas visualmente y no regeneres ningún elemento. El componente entregado es la fuente visual aprobada. El teléfono incluido corresponde a la versión final de la Parte 01 y no debe reemplazarse por otra maqueta.

## Trabajo permitido

1. Copiar el componente a `components/landing/GananzaLanding.tsx`.
2. Renderizarlo desde la ruta pública inicial con el patrón de `page.example.tsx`.
3. Adaptar únicamente las URLs de ingreso y registro a las rutas reales ya existentes.
4. Conectar los enlaces de términos, privacidad y soporte si esas páginas ya existen.
5. Resolver incompatibilidades técnicas mínimas de TypeScript, React o Next.js sin cambiar el resultado visual.
6. Mantener la landing fuera de las rutas autenticadas y preservar el comportamiento actual del panel.

## Prohibido

- No cambiar textos, colores, gradientes, tamaños, espaciados, radios o proporciones.
- No sustituir SVG, iconos, teléfono, monedas, glow u órbitas.
- No instalar librerías de UI ni animación.
- No tocar Supabase, migraciones, RLS, tablas, funciones, callbacks, retiros o ledger.
- No reemplazar la landing por una interpretación propia.
- No eliminar `prefers-reduced-motion`, responsive ni animaciones de entrada.

## Validación obligatoria

- Ejecutar lint y typecheck.
- Ejecutar build de producción.
- Verificar que no existan errores de hidratación.
- Probar 360×800, 390×844, 768×1024, 1024×768 y 1440×900.
- Confirmar que el teléfono no se corte en móvil.
- Confirmar que el header, CTAs y anclas funcionen.
- Confirmar que las rutas privadas y la autenticación sigan funcionando igual.

Al terminar, informá exactamente qué archivos cambiaste, qué rutas conectaste, los comandos ejecutados y cualquier diferencia inevitable respecto de la referencia.
