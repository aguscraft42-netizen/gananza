# Gananza — Parte 08: paquete de integración

Este paquete convierte la landing aprobada en un componente autónomo para Next.js App Router. No requiere imágenes externas ni librerías visuales adicionales.

## Archivos

- `GananzaLanding.tsx`: componente completo, responsive y animado. Incluye el teléfono aprobado de la Parte 01 como única versión visual.
- `page.example.tsx`: ejemplo mínimo para renderizarlo desde `app/page.tsx`.
- `gananza-landing-reference.html`: referencia visual integrada de la Parte 07.
- `CODEX_PROMPT.md`: instrucciones estrictas para integrarlo sin rediseñar.

## Integración manual

1. Copiar `GananzaLanding.tsx` a `components/landing/GananzaLanding.tsx`.
2. Importarlo desde la página pública principal.
3. Reemplazar únicamente los destinos `/acceso` y `/acceso?mode=register` si el proyecto usa otras rutas de autenticación.
4. No modificar estilos, proporciones, textos, animaciones ni el teléfono durante la primera integración.
5. Comprobar en 360 px, 390 px, 768 px, 1024 px y 1440 px.

## Límites de esta entrega

Los botones tienen destinos de ejemplo y deben conectarse con las rutas reales existentes. Los enlaces legales y de soporte que usan `#` necesitan sus destinos definitivos. La integración no debe alterar Supabase, autenticación, base de datos, RLS, APIs ni el panel interno.
